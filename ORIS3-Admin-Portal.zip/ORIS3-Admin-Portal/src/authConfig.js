/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { LogLevel } from "@azure/msal-browser";

/**
 * Configuration object to be passed to MSAL instance on creation. 
 * For a full list of MSAL.js configuration parameters, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md 
 */
export const msalConfig = {
    auth: {
        clientId: process.env.REACT_APP_CLIENTID,
        authority: "https://login.microsoftonline.com/30f52344-4663-4c2e-bab3-61bf24ebbed8",
        redirectUri: process.env.REACT_APP_REDIRECT_URI 
    },
    cache: {
        cacheLocation: "sessionStorage", // This configures where your cache will be stored
        storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
    },

    system: {	
        loggerOptions: {	
            loggerCallback: (level, message, containsPii) => {	
                if (containsPii) {		
                    return;		
                }		
                switch (level) {		
                    case LogLevel.Error:		
                        console.error(message);		
                        return;		
                    case LogLevel.Info:		
                        console.info(message);		
                        return;		
                    case LogLevel.Verbose:		
                        console.debug(message);		
                        return;		
                    case LogLevel.Warning:		
                        console.warn(message);		
                        return;		
                }	
            }	
        }	
    }
};

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) to any login request.
 * For more information about OIDC scopes, visit: 
 * https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-permissions-and-consent#openid-connect-scopes
 */
export const loginRequest = {
    //scopes: ["User.Read"]
    scopes: [
        //"0f85602c-5d62-40ac-a439-404d23dc7b9e/.default" //DEV
        //"418f9b28-b5e8-40e9-a195-44123994c441/.default" //INT
         "af4e859f-2d0f-46dc-ab2b-c91fdb961c75/.default"  //DEV
        //"af4e859f-2d0f-46dc-ab2b-c91fdb961c75/.default"  //INT
        //"af4e859f-2d0f-46dc-ab2b-c91fdb961c75/.default"  //SYT
        //"af4e859f-2d0f-46dc-ab2b-c91fdb961c75/.default"  //PROD
    ]
};

/**
 * Add here the scopes to request when obtaining an access token for MS Graph API. For more information, see:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/resources-and-scopes.md
 */
export const graphConfig = {
    //graphMeEndpoint: "https://dev-we-apim-oris3-admin.azure-api.net/admin/api/.auth/me"
    //graphMeEndpoint: "https://graph.microsoft.com/v1.0/me"
    graphMeEndpoint: "https://dev-we-apim-oris3-admin.azure-api.net/admin/api/Brand"
    //graphMeEndpoint: "https://hapikeys.azurewebsites.net/api/keyss?code=5GrJicvuaUaxXI124zQXvFtz0FEE0nhjiBHAzrna6CKH9q8FFvsNiQ==&appid=APP0001"
};
