import React, { Component,useState} from 'react'
import Table from 'react-bootstrap/Table'
//import Container from 'react-bootstrap/Container'
import Button from 'react-bootstrap/Button'
import httpCommon, { getHttpCommon } from '../../httpCommon'
import Pagination from '../../components/Pagination';
import UserContext from './../Context/SampleContext'
import Modal from 'react-bootstrap/Modal'
import { isWritePermission, validateRole } from '../../Constants/Utilities'
import Dropdown from 'react-bootstrap/Dropdown';
import e from 'cors';
import { loginRequest } from "../../authConfig";
import { format } from 'date-fns'
import LoadingSpinner from '../../LoadingSpinner';
import CryptoJS from "crypto-js"
import {decode as base64_decode, encode as base64_encode} from 'base-64';
import {exportExcel, exportCSV, vaidateUserData, exportExcelMoreSheets} from "../../components/ExportAsFileUtil"
import Popup from 'reactjs-popup';
import excelTempalte from '../storeid.xlsx'
import Form from 'react-bootstrap/Form'
import {decryptAES} from '../../components/AESHelper'

export default class User extends Component {
  static contextType = UserContext;

  constructor(props, context) {
    super(props, context);
    this.pageSize = 10

    this.loginUserRoles = []
    if (context.accountObj[0] != undefined) {
      this.loginUserRoles = context.accountObj[0].idTokenClaims?.roles;
    }
    this.mslInstance = context.msalObj;

    //State object to handle data in the UI
    this.state = {
      users: [],
      usersBase: [],
      currentPage: 1,
      openDialog: false,
      openSucessDialog: false,
      selectedFile: null,
      selectedFileName: "",
      filterValue: "",
      filterInput: "",
      accessToken: "",
      isLoading: false,
      formData: null,
      emailId:  context.userEmail
    }
    this.loginUserPermission = context.userPermission
    this.loginUserEmail = context.userEmail
    this.loginUserName = context.userName
    this.inputDisable = true
    this.regenerateDisable = true
    this.dowloadPassDisable = true
  }

  componentDidMount() {
    this.setState({ isLoading: true })
    this.mslInstance.acquireTokenSilent({
      ...loginRequest,
      account: this.loginUserRoles
    }).then((response) => {

      this.setState({ accessToken: response.accessToken })
      //callMsGraph(response.accessToken).then(response => setGraphData(response));
      this.loadUsers(response.accessToken, false)
    });
  }


  //To delete selected user details in the list
  deleteUser(userId, storeId, e) {
    var proceed = window.confirm("Are you sure you want to proceed to delete the User (" + userId + ") from the store " + storeId);
    if (proceed) {
      getHttpCommon(this.state.accessToken).delete('api/user/' + userId + '/' + storeId)
        .then(res => {
          window.location.reload(false);

        }).catch(function (error) {
          console.log(JSON.stringify(error))
          var response = error.response;
          var errorMessage = response.data.detail;
          alert(errorMessage);

        });

    } else {
      // alert("Don't Delete "+ id);
    }
  }

  //To delete selected user details in the list
  showPasscode(userId, storeId, e) {
    var proceed = window.confirm("Are you sure you want to user Passcode? ");
    if (proceed) {
      //Create base64 string
      let encodedUserId = base64_encode(userId);
      getHttpCommon(this.state.accessToken).get('api/user/getpasscode/' + encodedUserId +"/" +storeId )
        .then(res => {
          //alert(base64_decode(res.data));
          var result = decryptAES(res.data, process.env.REACT_APP_AES_KEY)
          alert(result);
        }).catch(function (error) {
          alert(error.message);
        });

    } else {
      // alert("Don't Delete "+ id);
    }
  }

  //To load user list
  loadUsers(accessToken, onlyPasscodeExpired) {

    //TODO: ***** Validate the ROLE and build the Route *****

    //[HM_SADMIN Role]: Load All Store items as it is super admin
    //var routePath = 'api/user' 

    //[HM_ADMIN Role]: Load Store List by login user email 
    var path = 'api/user'
    var isSuperAdmin = validateRole(this.loginUserRoles, ["HM_SADMIN"]);
    if (isSuperAdmin) {
      //[HM_SADMIN Role]: Load All Store items as it is super admin
      path = 'api/user';
    }
    else {
      //[HM_ADMIN Role]: Load Store List by login user email 
      path = 'api/user/' + this.loginUserEmail
    }
    if (onlyPasscodeExpired) {
      path = 'api/user/FilterByPinExpired/' + this.loginUserEmail
    }

    getHttpCommon(accessToken).get(path)
      // httpCommon.get('api/user')
      .then(res => {
        const usersdata = res.data;

        //Object 1: This object will carry the actual response
        this.setState({ usersBase: usersdata });

        //Object 2: This object will be bind in UI
        this.setState({ users: usersdata });

        //Note: the offline filter option will filter data from Object 1 and assign result to Object 2
        this.setState({ isLoading: false })

      }).catch(function (error) {
        this.setState({ isLoading: false })
        var response = error.response;
        if (response.data != null) {
          var errorMessage = response.data.detail;
          alert(errorMessage);
        }
        else {
          alert(error);
        }
      });
  }

  /* setCurrentPage() {
    this.setState({ currentPage: 0 })
  }
  */

  currentTableData = () => {
    let firstPageIndex = (this.state.currentPage - 1) * this.pageSize;
    let lastPageIndex = firstPageIndex + this.pageSize;
    return this.state.users.slice(firstPageIndex, lastPageIndex);
  }

  setCurrentPage(page) {
    this.setState({ currentPage: page });
  }

  handleClose() {
    this.setState({ openDialog: false });
  }

  handleFilterChange = (event) => {

    this.setState({ filterValue: event.target.value });
    var filteredUser = ""
    this.setState({ filterInput: "" });

    if (event.target.value == "expiryUser") {
      this.inputDisable = true
      filteredUser = this.state.usersBase.filter(function (user) {
        return user.isPasscodeExpired.toLowerCase() == "true"
      });
      this.setState({ users: filteredUser });
      this.regenerateDisable = filteredUser.length > 0 ? false : true

    } else if (event.target.value == "filter") {
      this.inputDisable = true
      this.setState({ users: this.state.usersBase })
    }
    else {
      this.inputDisable = false
      this.setState({ users: this.state.usersBase })
    }
  }

  handleFilterText = (event) => {
    this.setState({ filterInput: event.target.value.toLowerCase() })

    if (this.state.filterInput != "null" && this.state.filterInput != "undefined") {
      var filteredUser = ""
      //this.dowloadPassDisable = event.target.value.length > 0 ? false : true
      switch (this.state.filterValue) {
        case 'email':
          filteredUser = this.state.usersBase.filter(function (user) {
            return user.email.toLowerCase().match(event.target.value.toLowerCase())
          });
          break;
        case 'firstName':
          filteredUser = this.state.usersBase.filter(function (user) {
            return user.firstName.toLowerCase().match(event.target.value.toLowerCase())
          });
          break;
        case 'lastName':
          filteredUser = this.state.usersBase.filter(function (user) {
            return user.lastName.toLowerCase().match(event.target.value.toLowerCase())
          });
          break;
        case 'userId':
          filteredUser = this.state.usersBase.filter(function (user) {
            return user.userId.toLowerCase().match(event.target.value.toLowerCase())
          });
          break;
        case 'storeId':
          filteredUser = this.state.usersBase.filter(function (user) {
            return user.mappedToStore.toLowerCase().match(event.target.value.toLowerCase())
          });
          this.dowloadPassDisable = (filteredUser.length > 0 && event.target.value.length > 0)? false : true
          break;
      }
      this.setState({ users: filteredUser });
    } else {
      alert("please select a valid filter")
    }
  }

  callbackValidateBulkDataTemplate = (statusMessage) => {
    if(statusMessage=="success"){
        getHttpCommon(this.state.accessToken).post('api/User/userupload', this.state.formData)
            .then(res => {
              const result = res.data
              //console.log(result);
              if(Array.isArray(result))
              {
                result[0].data.map(userInfo => {
                  //userInfo.result = base64_decode(userInfo.result)
                  userInfo.result = decryptAES(userInfo.result, process.env.REACT_APP_AES_KEY)
                });

                exportExcelMoreSheets(result, "UserPasscode");
                this.setState({ openDialog: false })

                alert("Bulk user onboard is processed successfully. Please check the downloded excel file for modetails")
              }
              else
              {
                alert("Failure \n User's Not Onboarded \n Could you please try again later!!")
              }
            }).catch(function (error) {
              console.log(error)
              var response = error.response;
              var errorMessage = response.data.detail;
              alert(errorMessage);
              //console.log(errorMessage)
            });
      }
      else
      {
        alert(statusMessage)
      }
  }


  handleSubmit = (event) => {
    event.preventDefault()

    var selectedFileName = this.state.selectedFileName
    var selectedFile = this.state.selectedFile
    if (selectedFile != null && selectedFileName != null) {
      const formData = new FormData();
      formData.append("UserId", this.loginUserEmail);
      formData.append("files", this.state.selectedFile);
      //formData.append("FileName", this.state.selectedFileName);
      formData.append("Email", this.state.emailId);
      
      this.setState({formData: formData})

      //Validate excel file template
      vaidateUserData(this.state.selectedFile,this.callbackValidateBulkDataTemplate );
      
    } else {
      alert("Please upload valid user data")
    }

  }

  handleFileSelect = (event) => {
    // setSelectedFile(event.target.files[0])
    this.setState({ selectedFile: event.target.files[0] })
    this.setState({ selectedFileName: event.target.files[0].name })
  }

  handleSucessClose() {
    this.setState({ openSucessDialog: false })
  }

  handleEmailIdChange = event => {
    this.setState({ emailId: event.target.value });
}

  regeneratePasscode() {
    getHttpCommon(this.state.accessToken).post('api/User/regeneratebulkpass', this.state.users)
      .then(res => {
        const status = res.statusText
        if (status == "OK") {
          const result = res.data
          alert(result)
        } else {
          alert("Not able to Re-generate passcode \n Please use edit option to re-generate")
        }
      }).catch(function (error) {
        //var response = error.response;
        //var errorMessage = response.data.detail;
        // alert(errorMessage);
        // console.log(errorMessage)
      });
  }

  downloadPasscodes(){
    //form inputs
    //Managerid = ? NEED to fetch this value from the header section (Login user info)

    //Store id = ? Need to decide 
    let storeId = '';
    if(this.state.users.length>0){
      storeId= this.state.users[0].mappedToStore;
    }

    //User ids = need to collect it from selected users object array
    let userIds = this.state.users.map(user=> "'" + user.userId + "'").join(',')

    const passcodeRequest = {
      userIds: this.state.users.map(user=> user.userId),
      storeId: storeId,
      managerUserid: "",
      exportType: ""
    };

    console.log(userIds)
    
    if(storeId.length>0 && userIds.length>0){
      //Call the API
      //getHttpCommon(this.state.accessToken).get('api/User/downloadUserPasscodes?storeId=' + storeId + '&exportType=json&userIds=' + userIds)
      //getHttpCommon(this.state.accessToken).post('api/User/downloadUserPasscodes?storeId=' + storeId + '&exportType=json&userIds=' + userIds)

      getHttpCommon(this.state.accessToken).post('api/User/downloadUserPasscodes', passcodeRequest)
      .then(res => {
          const userPasscodes = res.data;
          //console.log(userPasscodes); //TODO: Remove this statement before push the code
          exportExcel(userPasscodes, "StoreUserData", "UserPasscode");
      }).catch(function (error) {
          console.log("Upload Error:" + error)
          alert("Technical Error.");
      });
    }
  }

  render() {
    const { users, currentPage } = this.state;
    return (
      <div className="containerStyle">
        <div className="subHeaderContainer">
          <div className="subTitle">Users ({this.state.users.length})</div>
          <div className="subButtonSec">

            <select style={{ margin: '10px', padding: '2px' }}
              value={this.state.filterValue}
              onChange={this.handleFilterChange}>
              <option value="filter">Filter By</option>
              <option value="email">Email</option>
              <option value="userId">UserId</option>
              <option value="firstName">First Name</option>
              <option value="lastName">Last Name</option>
              <option value="storeId">Store Id</option>
              <option value="expiryUser">Passcode Expired User</option>
            </select>
            <input onChange={this.handleFilterText} disabled={this.inputDisable} value={this.state.filterInput} style={{ margin: '10px' }} placeholder="Search text here"></input>
            {this.state.filterValue == "expiryUser" ?
              <Button variant="secondary" disabled={this.regenerateDisable} style={{ margin: '10px' }}
                onClick={() => { if (window.confirm('Are you sure you wish to Re-generate passcode for all user?')) { this.regeneratePasscode() } }}>Re-Generate Passcode</Button> :
              null}
            <Button variant="secondary" disabled={!validateRole(this.loginUserPermission, ["HM_SADMIN", "HM_ADMIN","HM_PADMIN"])} style={{ margin: '10px' }} onClick={() => this.props.history.push('/createuser')}>Onboard a Store User</Button>
            <Button variant="secondary" disabled={!validateRole(this.loginUserPermission, ["HM_SADMIN", "HM_ADMIN","HM_PADMIN"])} style={{ margin: '10px' }} onClick={() => this.setState({ openDialog: true })}>Onboard Bulk Store Users</Button>
            
            {this.state.filterValue == "disabled-storeId" ?
              <Button variant="secondary" disabled={!(validateRole(this.loginUserPermission, ["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]) && !this.dowloadPassDisable)} style={{ margin: '10px' }} onClick={() => this.downloadPasscodes()}>Download User Passcodes</Button>:
              null}
          </div>
        </div>
        <Modal show={this.state.openDialog} onHide={() => this.handleClose()}>
          <Modal.Header >
            <Modal.Title> Onboard Bulk Store Users</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div style={{ marginBottom: '20px' }}>
              <a href={excelTempalte} target="_blank">Download Excel File Template</a>
            </div>

            <form onSubmit={this.handleSubmit}>
            <Form style={{ marginBottom: '20px', display:'none'}}>
            <Form.Group>
                  <Form.Label>Email ID to send this report</Form.Label>
                  <Form.Control
                      required
                      type="text"
                      placeholder="Email Id"
                      value={this.state.emailId}
                      onChange={this.handleEmailIdChange}
                  />
                  <Form.Control.Feedback type="invalid">
                      Please provide email Id
                  </Form.Control.Feedback>
              </Form.Group>
              </Form>
              <input type="file" onChange={this.handleFileSelect} accept=".xlsx, .xls" />
              <input type="submit" value="Start Onboard" />
            </form>
          </Modal.Body>
        </Modal>
        {this.state.isLoading ? LoadingSpinner(this.state.isLoading) :

          (<Table striped bordered hover>
            <thead>
              <tr>
                <th>User Id</th>
                <th>Store</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Passcode Valid To</th>
                <th>Action</th>
              </tr>
            </thead>

            {this.state.users.length > 0 ?
              <tbody>
                {this.currentTableData().map((item, index) => (
                  <tr key={index}>
                    <td style={item.isPasscodeExpired.toLowerCase() == "true" ? { color: '#C70039' } : { color: 'black' }}>{item.userId}</td>
                    <td style={item.isPasscodeExpired.toLowerCase() == "true" ? { color: '#C70039' } : { color: 'black' }}>{item.mappedToStore}</td>
                    <td style={item.isPasscodeExpired.toLowerCase() == "true" ? { color: '#C70039' } : { color: 'black' }}>{item.firstName}</td>
                    <td style={item.isPasscodeExpired.toLowerCase() == "true" ? { color: '#C70039' } : { color: 'black' }}>{item.lastName}</td>
                    <td style={item.isPasscodeExpired.toLowerCase() == "true" ? { color: '#C70039' } : { color: 'black' }}>{item.email}</td>
                    <td style={item.isPasscodeExpired.toLowerCase() == "true" ? { color: '#C70039' } : { color: 'black' }}>{item.roleName}</td>
                    <td style={item.isPasscodeExpired.toLowerCase() == "true" ? { color: '#C70039' } : { color: 'black' }}>{format(new Date(item.passCodeValidTo), 'dd-MM-yyyy')}</td>
                    <td>
                      <div style={{ display: 'flex' }}>
                        <Button disabled={!validateRole(this.loginUserPermission, ["HM_SADMIN", "HM_ADMIN","HM_PADMIN"])} onClick={() => this.props.history.push('/updateuser/' + item.userId + '/' + item.mappedToStore)}>Update</Button>
                        <Button disabled={!validateRole(this.loginUserPermission, ["HM_SADMIN", "HM_ADMIN","HM_PADMIN"])} variant="danger" onClick={(e) => this.deleteUser(item.userId, item.mappedToStore, e)} style={{ marginLeft: '10px' }}>Delete</Button>
                        {item.isFirstTimePasscode==true ?
                        <Button disabled={!validateRole(this.loginUserPermission, ["HM_SADMIN", "HM_ADMIN","HM_PADMIN"])} variant="secondary" onClick={(e) => this.showPasscode(item.userId, item.mappedToStore, e)} style={{ marginLeft: '10px' }}>Show Passcode</Button>:
                        null}
                      </div>

                    </td>
                  </tr>
                ))}
              </tbody> : <p>Result Not Found. Please use some other Filter Option</p>}
          </Table>)}
        <Pagination
          className="pagination-bar"
          currentPage={currentPage}
          totalCount={users.length}
          pageSize={this.pageSize}
          onPageChange={page => this.setCurrentPage(page)}
        />
      </div>
    )
  }
}
