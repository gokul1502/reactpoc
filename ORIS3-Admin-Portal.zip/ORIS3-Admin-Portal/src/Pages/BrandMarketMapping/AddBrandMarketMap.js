import React from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import httpCommon, {getHttpCommon} from '../../httpCommon'
import {isWritePermission,validateRole} from '../../Constants/Utilities'
import UserContext from './../Context/SampleContext'
import { loginRequest } from "../../authConfig";

export default class AddBrandMarketMap extends React.Component {
    static contextType = UserContext;

    constructor(props,context) {
        super(props,context)
        this.state = {
            validated: false,
            slf: false,
            bestSellingPotentialEnabled: false,
            taxCalculationEnabled: false,
            shippingFeeExcluded: false,
            keepOrSendDefault: "Keep",
            brands: [],
            markets: [],
            accessToken: ''
        }

        this.loginUserRoles = []
        if(context.accountObj[0]!=undefined){
          this.loginUserRoles =  context.accountObj[0].idTokenClaims?.roles;
        }
        this.mslInstance = context.msalObj;
        
        this.loginUserPermission = context.userPermission
        this.disable = false
        this.disable = validateRole(this.loginUserPermission, ["HM_SADMIN"])
    }

    componentDidMount() {
        this.mslInstance.acquireTokenSilent({
            ...loginRequest,
            account: this.loginUserRoles
        }).then((response) => {
          console.log(response.accessToken);
            //callMsGraph(response.accessToken).then(response => setGraphData(response));
            this.setState({ accessToken: response.accessToken })
            this.loadBrandsList(response.accessToken)
            this.loadMarketsList(response.accessToken)
        });
    }

    loadBrandsList(accessToken){
        getHttpCommon(accessToken).get('api/Brand')
        .then(res => {
            this.setState({
                brands: res.data
            });
        }).catch(function (error) {
            var response = error.response;
            var errorMessage = response.data.detail;
            alert(errorMessage);
        });
    }

    loadMarketsList(accessToken){
        getHttpCommon(accessToken).get('api/Market')
            .then(res => {
                this.setState({
                    markets: res.data
                });
            }).catch(function (error) {
                var response = error.response;
                var errorMessage = response.data.detail;
                alert(errorMessage);
            });
    }

    handleCountryChange = event => {
        this.setState({ country: event.target.value });
    }

    handleBrandIdChange = event => {
        this.setState({ brandId: event.target.value });
    }

    handleDummyWarehouseIdChange = event => {
        this.setState({ dummyWarehouseId: event.target.value });
    }

    handleSlfChange = event => {
        this.setState({ slf: event.target.checked });
    }

    handleBspEnabledChange = event => {
        this.setState({ bestSellingPotentialEnabled: event.target.checked });
    }

    handleTaxCalEnabledChange = event => {
        this.setState({ taxCalculationEnabled: event.target.checked });
    }

    handleShippingFeeEnabledChange = event => {
        this.setState({ shippingFeeExcluded: event.target.checked });
    }

    handleKeepOrSendDefaultChange = (event) => {
        this.setState({ keepOrSendDefault: event.target.value });
    };

    backBtnClick = (event) => {
        event.preventDefault();
        window.location.href = '/brandmarketmaps';
    };

    handleSubmit = event => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            this.setState({ validated: true });
            event.preventDefault();
            event.stopPropagation();
        }
        else {
            event.preventDefault();

            const brandMarketMapDetail = {
                country: this.state.country,
                brandId: this.state.brandId,
                dummyWarehouseId: this.state.dummyWarehouseId,
                slf: this.state.slf,
                bestSellingPotentialEnabled: this.state.bestSellingPotentialEnabled,
                taxCalculationEnabled : this.state.taxCalculationEnabled,
                shippingFeeExcluded: this.state.shippingFeeExcluded,
                keepOrSendDefault: this.state.keepOrSendDefault,
            };

            getHttpCommon(this.state.accessToken).post('api/brandmarketmap', brandMarketMapDetail)
                .then(res => {
                    alert(res.data);
                    //window.location.href = '/brandmarketmaps';
                }).catch(function (error) {
                    var response = error.response;
                    var errorMessage = response.data;
                    alert(errorMessage);
                });
        }
    }

    render() {
        return (
            <div id="container" className="containerStyle">
                <div className="row">
                    <div className="col-sm-10 offset-sm-1" style={{ marginTop: '20px' }}>
                        <div className="info-form" style={{ marginTop: '20px', width: '50%', margin: 'auto' }}>
                            <h4>Add New Brand Market Mapping</h4>
                            <Form noValidate validated={this.state.validated} onSubmit={this.handleSubmit}>
                                <Form.Group>
                                    <Form.Label>Country</Form.Label>
                                    <Form.Control as="select" placeholder="Store" required onChange={this.handleCountryChange} >
                                        <option value=''>--Select a Country--</option>
                                        {this.state.markets.map((item) => (
                                            <option value={item.country}>{item.country}</option>
                                        ))}
                                    </Form.Control>
                                    <Form.Control.Feedback type="invalid">
                                        Please provide Country
                                    </Form.Control.Feedback>
                                </Form.Group>
                                <Form.Group>
                                    <Form.Label>Brand</Form.Label>
                                    <Form.Control as="select" placeholder="Store" required onChange={this.handleBrandIdChange} >
                                        <option value=''>--Select a Brand--</option>
                                        {this.state.brands.map((item) => (
                                            <option value={item.brandId}>{item.name}</option>
                                        ))}
                                    </Form.Control>
                                    <Form.Control.Feedback type="invalid">
                                        Please provide Brand
                                    </Form.Control.Feedback>
                                </Form.Group>                                
                                <Form.Group className="mb-3" style={{ marginTop: '10px' }}>
                                    <Form.Check type="checkbox" label="SLF"
                                        onChange={this.handleSlfChange} />
                                </Form.Group>
                                <Form.Group className="mb-3" style={{ marginTop: '10px' }}>
                                    <Form.Check type="checkbox" label="Enable Best Selling Potential"
                                        onChange={this.handleBspEnabledChange} />
                                </Form.Group>
                                <Form.Group className="mb-3" style={{ marginTop: '10px' }}>
                                    <Form.Check type="checkbox" label="Tax Calculation"
                                        onChange={this.handleTaxCalEnabledChange} />
                                </Form.Group>
                                <Form.Group className="mb-3" style={{ marginTop: '10px' }}>
                                    <Form.Check type="checkbox" label="Exclude Shipping Fee"
                                        onChange={this.handleShippingFeeEnabledChange} />
                                </Form.Group>
                                <Form.Label>Keep Or Send Default</Form.Label>
                                <Form.Group className="mb-3">
                                    <Form.Check type="radio" id="idRadioKeep" name="exampleRadios" label="Keep" value="Keep" defaultChecked onChange={this.handleKeepOrSendDefaultChange} />
                                    <Form.Check type="radio" id="idRadioSend" name="exampleRadios" label="Send" value="Send" onChange={this.handleKeepOrSendDefaultChange} />
                                </Form.Group>
                                <div className='form-group'>
                                    <Button type="submit" style={{ marginTop: '10px' }}>Add Brand Market Mapping</Button>
                                    <Button type="submit" onClick={this.backBtnClick} style={{ marginTop: '10px', marginLeft: '10px' }}>Back</Button>
                                </div>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}