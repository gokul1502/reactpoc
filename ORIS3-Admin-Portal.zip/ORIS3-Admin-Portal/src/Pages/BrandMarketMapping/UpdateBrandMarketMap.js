import React from "react";
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import "react-datepicker/dist/react-datepicker.css";
import "react-datepicker/dist/react-datepicker-cssmodules.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import httpCommon, {getHttpCommon} from '../../httpCommon'
import {isWritePermission,validateRole} from '../../Constants/Utilities'
import UserContext from './../Context/SampleContext'
import { loginRequest } from "../../authConfig";

export default class UpdateBrandMarketMap extends React.Component {
    static contextType = UserContext;
    
    constructor(props,context) {
        super(props,context)

        this.state = {
            country: '',
            validated: false,
            slf: false,
            bestSellingPotentialEnabled: false,
            taxCalculationEnabled: false,
            shippingFeeExcluded: false,
            brands: [],
            markets: [],
            accessToken: ''
        }

        this.loginUserRoles = []
        if(context.accountObj[0]!=undefined){
          this.loginUserRoles =  context.accountObj[0].idTokenClaims?.roles;
        }
        this.mslInstance = context.msalObj;
        
        this.loginUserPermission = context.userPermission
        this.disable = false
        this.disable = validateRole(this.loginUserPermission, ["HM_SADMIN"])
    }

    componentDidMount() {

        this.mslInstance.acquireTokenSilent({
            ...loginRequest,
            account: this.loginUserRoles
        }).then((response) => {
          console.log(response.accessToken);
            //callMsGraph(response.accessToken).then(response => setGraphData(response));
            this.setState({ accessToken: response.accessToken })
            this.loadBrandsList(response.accessToken)
            this.loadMarketsList(response.accessToken)
            this.loadBrandmappingList(response.accessToken)
        });
    }

    loadBrandsList(accessToken){
        getHttpCommon(accessToken).get('api/Brand')
        .then(res => {
            this.setState({
                brands: res.data
            });
        }).catch(function (error) {
            var response = error.response;
            var errorMessage = response.data.detail;
            alert(errorMessage);
        });
    }

    loadMarketsList(accessToken){
        getHttpCommon(accessToken).get('api/Market')
            .then(res => {
                this.setState({
                    markets: res.data
                });
            }).catch(function (error) {
                var response = error.response;
                var errorMessage = response.data.detail;
                alert(errorMessage);
            });
    }

    loadBrandmappingList(accessToken){
        var path = window.location.pathname.split('/');
        var countryCode = path[2];
        var brandId = path[3];
        getHttpCommon(accessToken).get('api/brandmarketmap/' + countryCode + '/' + brandId)
            .then(res => {
                const brandmarketmap = res.data;
                this.setState({
                    country: brandmarketmap.country,
                    brandId: brandmarketmap.brandId,
                    slf: brandmarketmap.slf,
                    bestSellingPotentialEnabled: brandmarketmap.bestSellingPotentialEnabled,
                    taxCalculationEnabled : brandmarketmap.taxCalculationEnabled,
                    shippingFeeExcluded: brandmarketmap.shippingFeeExcluded,
                    keepOrSendDefault: brandmarketmap.keepOrSendDefault
                });
                if (brandmarketmap.keepOrSendDefault === 'Keep')
                    this.setState({ keepFlag: true, sendFlag: false });
                if (brandmarketmap.keepOrSendDefault === 'Send')
                    this.setState({ keepFlag: false, sendFlag: true });
            }).catch(function (error) {
                alert(error);
            });
    }

    handleCountryChange = event => {
        this.setState({ country: event.target.value });
    }

    handleBrandIdChange = event => {
        this.setState({ brandId: event.target.value });
    }

    handleSlfChange = event => {
        this.setState({ slf: event.target.checked });
    }

    handleBspEnabledChange = event => {
        this.setState({ bestSellingPotentialEnabled: event.target.checked });
    }

    handleTaxCalEnabledChange = event => {
        this.setState({ taxCalculationEnabled: event.target.checked });
    }

    handleShippingFeeEnabledChange = event => {
        this.setState({ shippingFeeExcluded: event.target.checked });
    }

    handleKeepOrSendDefaultChange = (event) => {
        if (event.target.value === 'Keep')
            this.setState({ keepFlag: true, sendFlag: false });
        if (event.target.value === 'Send')
            this.setState({ keepFlag: false, sendFlag: true });
        this.setState({ keepOrSendDefault: event.target.value });
    };

    backBtnClick = (event) => {
        event.preventDefault();
        window.location.href = '/brandmarketmaps';
    };

    handleSubmit = event => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            this.setState({ validated: true });
            event.preventDefault();
            event.stopPropagation();
        }
        else {
            event.preventDefault();

            const brandMarketMapDetail = {
                country: this.state.country,
                brandId: this.state.brandId,
                slf: this.state.slf,
                bestSellingPotentialEnabled: this.state.bestSellingPotentialEnabled,
                taxCalculationEnabled: this.state.taxCalculationEnabled,
                shippingFeeExcluded: this.state.shippingFeeExcluded,    
                keepOrSendDefault: this.state.keepOrSendDefault,
            };

            var path = window.location.pathname.split('/');
            var countryCode = path[2];
            var brandId = path[3];

            getHttpCommon(this.state.accessToken).put('api/brandmarketmap/' + countryCode + '/' + brandId, brandMarketMapDetail)
                .then(res => {
                    alert(res.data);
                    //window.location.href = '/brandmarketmaps';
                }).catch(function (error) {
                    var response = error.response;
                    var errorMessage = response.data;
                    alert(errorMessage);
                });
        }
    }

    render() {
        return (
            <div id="container" className="containerStyle">
                <div className="row">
                    <div className="col-sm-10 offset-sm-1" style={{ marginTop: '20px' }}>
                        <div className="info-form" style={{ marginTop: '20px', width: '50%', margin: 'auto' }}>
                            <h4>Update Brand Market Mapping</h4>
                            <Form noValidate validated={this.state.validated} onSubmit={this.handleSubmit}>
                                <Form.Group>
                                    <Form.Label>Country</Form.Label>
                                    <Form.Control as="select" placeholder="Store" required value={this.state.country} onChange={this.handleCountryChange} >
                                        <option value=''>--Select a Country--</option>
                                        {this.state.markets.map((item) => (
                                            <option value={item.country}>{item.country}</option>
                                        ))}
                                    </Form.Control>
                                    <Form.Control.Feedback type="invalid">
                                        Please select Country
                                    </Form.Control.Feedback>
                                </Form.Group>
                                <Form.Group>
                                    <Form.Label>Brand</Form.Label>
                                    <Form.Control as="select" placeholder="Store" required value={this.state.brandId} onChange={this.handleBrandIdChange} >
                                        <option value=''>--Select a Brand--</option>
                                        {this.state.brands.map((item) => (
                                            <option value={item.brandId}>{item.name}</option>
                                        ))}
                                    </Form.Control>
                                    <Form.Control.Feedback type="invalid">
                                        Please select Brand
                                    </Form.Control.Feedback>
                                </Form.Group>
                                <Form.Group className="mb-3" style={{ marginTop: '10px' }}>
                                    <Form.Check type="checkbox" label="SLF" checked={this.state.slf}
                                        onChange={this.handleSlfChange} />
                                </Form.Group>
                                <Form.Group className="mb-3" style={{ marginTop: '10px' }}>
                                    <Form.Check type="checkbox" label="Best Selling Potential" checked={this.state.bestSellingPotentialEnabled}
                                        onChange={this.handleBspEnabledChange} />
                                </Form.Group>
                                <Form.Group className="mb-3" style={{ marginTop: '10px' }}>
                                    <Form.Check type="checkbox" label="Tax Calculation" checked={this.state.taxCalculationEnabled} 
                                        onChange={this.handleTaxCalEnabledChange} />
                                </Form.Group>
                                <Form.Group className="mb-3" style={{ marginTop: '10px' }}>
                                    <Form.Check type="checkbox" label="Exclude Shipping Fee" checked={this.state.shippingFeeExcluded} 
                                        onChange={this.handleShippingFeeEnabledChange}/>
                                </Form.Group>
                                <Form.Label>Keep Or Send Default</Form.Label>
                                <Form.Group className="mb-3">
                                    <Form.Check type="radio" id="idRadioKeep" name="exampleRadios" label="Keep" value="Keep" checked={this.state.keepFlag} onChange={this.handleKeepOrSendDefaultChange} />
                                    <Form.Check type="radio" id="idRadioSend" name="exampleRadios" label="Send" value="Send" checked={this.state.sendFlag} onChange={this.handleKeepOrSendDefaultChange} />
                                </Form.Group>
                                <div className='form-group'>
                                    <Button type="submit" style={{ marginTop: '10px' }}>Update Brand Market Mapping</Button>
                                    <Button type="submit" onClick={this.backBtnClick} style={{ marginTop: '10px', marginLeft: '10px' }}>Back</Button>
                                </div>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}