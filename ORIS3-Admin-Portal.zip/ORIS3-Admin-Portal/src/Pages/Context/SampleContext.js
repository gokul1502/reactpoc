import React from 'react'
export const SampleContext = React.createContext({ctx_key:"ctx_value"});   
export default SampleContext