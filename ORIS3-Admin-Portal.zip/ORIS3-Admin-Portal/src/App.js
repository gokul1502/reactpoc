import './App.css';
import { Route, Redirect, Switch, BrowserRouter as Router, BrowserRouter,Link } from 'react-router-dom';
import Home from './Pages/Home';
import ShowUsers from './Pages/User/ShowUsers';
import Navbar from 'react-bootstrap/Navbar'
import Nav from 'react-bootstrap/Nav'
import AddUser from './Pages/User/AddUser';
import UpdateUser from './Pages/User/UpdateUser'
import ShowBrands from "./Pages/Brand/ShowBrands"
import AddBrand from './Pages/Brand/AddBrand';
import UpdateBrand from './Pages/Brand/UpdateBrand';
import ShowStores from './Pages/Store/ShowStores';
import AddStore from './Pages/Store/AddStore';
import UpdateStore from './Pages/Store/UpdateStore';
import ShowDevices from './Pages/Device/ShowDevices'; // Devices
import ShowMarkets from './Pages/Market/ShowMarkets';
import AddMarket from './Pages/Market/AddMarket';
import UpdateMarket from './Pages/Market/UpdateMarket';
import ShowRoles from './Pages/Role/ShowRoles';
import AddRole from './Pages/Role/AddRole';
import UpdateRole from './Pages/Role/UpdateRole';
import ShowBrandMarketMaps from './Pages/BrandMarketMapping/ShowBrandMarketMaps';
import AddBrandMarketMap from './Pages/BrandMarketMapping/AddBrandMarketMap';
import UpdateBrandMarketMap from './Pages/BrandMarketMapping/UpdateBrandMarketMap';
import ShowCountryManagers from "./Pages/CountryManager/ShowCountryManagers"
import AddCountryManager from './Pages/CountryManager/AddCountryManager';
import UpdateCountryManager from './Pages/CountryManager/UpdateCountryManager';
import React, { useState, useEffect} from 'react'
import SampleContext from './Pages/Context/SampleContext';
import { AuthenticationState } from 'react-aad-msal';
import AppImage from './applogo.png';
import styled from 'styled-components';
import { validateRole } from './Constants/Utilities';

import { AuthenticatedTemplate, UnauthenticatedTemplate, useMsal }
  from "@azure/msal-react";
import { loginRequest } from "./authConfig";
import { getHttpCommon } from './httpCommon';
import PageNotFound from './components/PageNotFound';
import RouteNotFound from './components/RouteNotFound';
import { GlobalDebug } from "./components/GlobalDebug";

export default function App() {
  let permission = ""
  let name = "!"
  let email = "!"
  let userRoles = []
  let accessToken = "";
  const { instance } = useMsal();

  //Styled componet for Header section 
  const Styles = styled.div`
 '.navbar { 
   background-color: #F2F2F2 !important;
   }
 a, .navbar-nav, .navbar-light .nav-link {
   color: #001100;
   &:hover { color: maroon; }
 }
 .navbar-brand {
   font-size: 1.4em;
   color: #010;
   &:hover { color: maroon; }
 }
 .form-center {
   position: absolute !important;
   left: 25%;
   right: 25%;
 }
 `;

  useEffect(() => {
    (process.env.NODE_ENV === "production" ||
     process.env.REACT_APP_ENV === "STAGING" || process.env.REACT_APP_ENV === "PRODUCTION") &&
      GlobalDebug(false);
  }, []);

  const handleLogin = (loginType) => {
    if (loginType === "popup") {
      instance.loginPopup(loginRequest).catch(e => {
        console.log(e);
      });
    } else if (loginType === "redirect") {
      instance.loginRedirect(loginRequest).catch(e => {
        console.log(e);
      });
    }
  }

  const handleLogout = (logoutType) => {  
    if (logoutType === "popup") {
      instance.logoutPopup({
        postLogoutRedirectUri: "/",
        mainWindowRedirectUri: "/"
      });
    } else if (logoutType === "redirect") {
      instance.logoutRedirect({
        postLogoutRedirectUri: "/",
      });
    }
  }

  const LoginSuccessContent = (props) => {

    useEffect(() => {
      console.log("Homepage======>", props);
    });

    const [storeDet, setStoreValue] = useState(" ");
    const { instance, accounts } = useMsal();
    const [graphData, setGraphData] = useState(null);

    if (accounts[0] != undefined) {
      //Read Name
      name = accounts[0].name;
      console.log(accounts);

      //Read email address
      email = accounts[0].username;

      //Read permissions
      permission = accounts[0].idTokenClaims?.roles;
      console.log("permission======>", permission);

      //Read Roles
      userRoles = accounts[0].idTokenClaims?.roles;
        instance.acquireTokenSilent({
          ...loginRequest,
          account: accounts[0]
        }).then((response) => {
          let accessToken = response.accessToken
          let path = 'api/Store/storeByUserEmail/' + email
          // https://dev-we-webapp-adminportal-api.azurewebsites.net/api/Store/storeByUserId/A1219784
          getHttpCommon(accessToken).get(path)
            .then(res => {
              setStoreValue(res.data[0].storeName + " (" +res.data[0].storeId + ")" )
              //this.setState({ store: res.data[0].storeName })
              // store = res.data[0].storeName
              console.log("RES_!", res.data[0].storeName)
            }).catch(function (error) {
              var response = error.response;
              var errorMessage = response.data.detail;
              alert(errorMessage);
            });

        });
    }

    const routes = [
      { path: ["/"], component: Home, exact: true, elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},
      { path: ["/home"], component: Home, elementRoles:["HM_SADMIN", "HM_ADMIN"]},

      //Users
      { path: ["/users"], component: ShowUsers, elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},
      { path: ["/createuser"], component: AddUser, elementRoles:["HM_SADMIN","HM_PADMIN", "HM_ADMIN"]},
      { path: ["/updateuser/:userId/:storeId"], component: UpdateUser,elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},

      //Stores
      { path: ["/stores"], component: ShowStores, elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},
      { path: ["/createstore"], component: AddStore, elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},
      { path: ["/updatestore/:storeId"], component: UpdateStore, elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},

      //Devices
      { path: ["/devices"], component: ShowDevices, elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},
      //{ path: ["/createstore"], component: AddStore, elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},
      //{ path: ["/updatestore/:storeId"], component: UpdateStore, elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},
    

      //Brands
      { path: ["/brands"], component: ShowBrands, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/createbrand"], component: AddBrand, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/updatebrand/:brandId"], component: UpdateBrand, elementRoles:["HM_SADMIN","HM_PADMIN"]},

      //Markets
      { path: ["/markets"], component: ShowMarkets, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/createmarket"], component: AddMarket, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/updatemarket/:marketId"], component: UpdateMarket, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      
      //Roles
      { path: ["/roles"], component: ShowRoles, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/createrole"], component: AddRole, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/updaterole/:roleId"], component: UpdateRole, elementRoles:["HM_SADMIN","HM_PADMIN"]},

      //Brand Market Mapping
      { path: ["/brandmarketmaps"], component: ShowBrandMarketMaps, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/createbrandmarketmap"], component: AddBrandMarketMap, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/updatebrandmarketmap/:country/:brandId"], component: UpdateBrandMarketMap, elementRoles:["HM_SADMIN","HM_PADMIN"]},

      //Country Manager
      { path: ["/countrymanagers"], component: ShowCountryManagers, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/createcountrymanager"], component: AddCountryManager, elementRoles:["HM_SADMIN","HM_PADMIN"]},
      { path: ["/updatecountrymanager/:id"], component: UpdateCountryManager, elementRoles:["HM_SADMIN","HM_PADMIN"]},

      { path: ["/*"], component: RouteNotFound, exact: true,elementRoles:["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]},
    ];

    const ACCESS_TOKEN = "token";

    const readFromStorage = (token) => token;
    const isFalsy = (val) => !Boolean(val);

    const PrivateRoute = (props) => {
      const accessToken = readFromStorage(ACCESS_TOKEN);
    
      return !isFalsy(accessToken) ? (
        <Route {...props} />
      ) : (
        <Redirect
          to={{
            pathname: "/login",
            state: { from: props.location }
          }}
        />
      );
    };

    return (
      <Router>
        <Styles>
          <Navbar bg="light" expand="lg">
            <Navbar.Brand href="/home"><h3><img src={AppImage} alt="horse" className="logoImage" /><b>ORIS 3.1 Admin portal</b></h3></Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav" >
              <Nav>
                {validateRole(userRoles, ["HM_SADMIN","HM_PADMIN"]) && <Nav.Link href='/brands'><b>Brands</b></Nav.Link>}
                {validateRole(userRoles, ["HM_SADMIN","HM_PADMIN"]) && <Nav.Link href='/markets'><b>Markets</b></Nav.Link>}
                {validateRole(userRoles, ["HM_SADMIN","HM_PADMIN"]) && <Nav.Link href='/roles'><b>Roles</b></Nav.Link>}
                {validateRole(userRoles, ["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]) && <Nav.Link href='/stores'><b>Stores</b></Nav.Link>}
                {validateRole(userRoles, ["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]) && <Nav.Link href='/devices'><b>Devices</b></Nav.Link>}
                {validateRole(userRoles, ["HM_SADMIN", "HM_ADMIN","HM_PADMIN"]) && <Nav.Link href='/users'><b>Users</b></Nav.Link>}
                {validateRole(userRoles, ["HM_SADMIN","HM_PADMIN"]) && <Nav.Link href='/countrymanagers'><b>Country Managers</b></Nav.Link>}
                {validateRole(userRoles, ["HM_SADMIN","HM_PADMIN"]) && <Nav.Link href='/brandmarketmaps'><b>Brand Market Mappings</b></Nav.Link>}
              </Nav>
            </Navbar.Collapse>
            <div className="user-info-container">
              <ul>
                <li><b>Welcome</b> {name}</li>
                <li>{storeDet}</li>
                <li className="logoutText">
                  <button onClick={() => handleLogout("redirect")} className="logingButton">Logout</button>
                </li>
              </ul>
            </div>
          </Navbar>
        </Styles>
          <SampleContext.Provider value={{ userPermission: permission, userName: name, userEmail: email, userRoles: userRoles, accountObj: accounts, msalObj: instance }}>
          <Switch>{routes.map(({elementRoles:eleRoles, ...props}) => {
            const RouteWrapper = validateRole(userRoles, eleRoles) ? Route: PageNotFound;
            return <RouteWrapper key={props.path[0]} {...props} />;
          })}
          </Switch>
          </SampleContext.Provider>
      </Router>
    );
  }

  return (
    <div className="App">
      <AuthenticatedTemplate>
        <LoginSuccessContent />
      </AuthenticatedTemplate>

      <UnauthenticatedTemplate>
        <Router>
          <Navbar bg="light" expand="lg">
            <Navbar.Brand href="/home"><h3><img src={AppImage} alt="horse" className="logoImage" /><b>ORIS 3.1 Admin portal</b></h3></Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
            </Navbar.Collapse>
            <div class="user-info-container">
              <ul>
                <li>Welcome {name}</li>
                <li class="logoutText">
                  <button onClick={() => handleLogin("redirect")} >LOGIN</button>
                </li>
              </ul>
            </div>
          </Navbar>
          <Switch>
            <SampleContext.Provider value={{ user_permission: permission, userName: name }}>
              <Route path="/" component={Home} />
            </SampleContext.Provider>
          </Switch>
        </Router>
      </UnauthenticatedTemplate>
    </div>
  )
}
