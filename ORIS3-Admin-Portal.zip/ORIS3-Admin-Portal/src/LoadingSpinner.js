import React from "react";
import ClipLoader from "react-spinners/ClipLoader";

const LoadingSpinner = (isLoading) => {
  return (
    <div style={{ paddingTop: 150 }}>
      <ClipLoader color={"#316CF4"} loading={isLoading} cssOverride={true} size={30} />
    </div>

  )
}

export default LoadingSpinner;