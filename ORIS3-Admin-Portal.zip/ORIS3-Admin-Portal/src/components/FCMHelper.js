export const sendPushNotification = async (token, title, body, isAlertRes) => {

  const FIREBASE_API_KEY ="<your firebase cloud messaging server key>"

  const message = {
    registration_ids: [token],
    notification: {
      title: title,
      body: body,
      vibrate: 1,
      sound: 1,
      show_in_foreground: true,
      priority: "high",
      content_available: true
    },
  };

  let headers = new Headers({
    "Content-Type": "application/json",
    Authorization: "key=" + process.env.REACT_APP_FB_SKEY
  });


  let response = await fetch("https://fcm.googleapis.com/fcm/send", {
    method: "POST",
    headers,
    body: JSON.stringify(message)
  });

  response = await response.json();

  console.log("=><*", response);

  if(isAlertRes == true){
    if(response.success == 1)
      alert("Message sent successfully!")
    else
    alert("Message sent failed!")
  }
  //alert("sendPushNotification" + process.env.REACT_APP_FB_SKEY)
}
