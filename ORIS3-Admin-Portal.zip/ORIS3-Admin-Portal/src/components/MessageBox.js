import React, { Component,useState} from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

export default class MessageBox extends Component {

    constructor(props,context) {
        super(props, context);  
        this.state = {
            show: this.props.show,
            title: this.props.title,
            message: this.props.message,
            cancelText: this.props.cancelText,
            doneText: this.props.doneText,
        }
    }

    handleCancel = () => {
        this.setState({ show: false })
        this.props.onCancel() //Callback message from the component subscriber
    }

    handleDone = () => {
        this.setState({ show: false })
        this.props.onDone() //Callback message from the component subscriber
    }

    handleShow = () => {
        this.setState({ show: true })
    }
    
    render() {
        return (
            <Modal show={this.state.show} onHide={this.handleCancel}>
                <Modal.Header closeButton>
                    <Modal.Title>{this.state.title}</Modal.Title>
                </Modal.Header>
                <Modal.Body>{this.state.message}</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={this.handleCancel}>
                    {this.state.cancelText}
                    </Button>
                    <Button variant="primary" onClick={this.handleDone}>
                    {this.state.doneText}
                    </Button>
                </Modal.Footer>
            </Modal>
        )
    }
};
