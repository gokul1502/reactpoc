import React from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import httpCommon, {getHttpCommon} from '../../httpCommon'
import { loginRequest } from "../../authConfig";
import {validateRole} from '../../Constants/Utilities'
import UserContext from './../Context/SampleContext'

export default class AddBrand extends React.Component {
    static contextType = UserContext;

    constructor(props,context) {
            super(props,context)

        this.state = {
            brandId: '',
            validated: false,
            accessToken: ""
        }

        if(context.accountObj[0]!=undefined){
            this.loginUserRoles =  context.accountObj[0].idTokenClaims?.roles;
          }
          this.mslInstance = context.msalObj;
        
        this.loginUserPermission = context.userPermission
        this.disable = false
        this.disable = validateRole(this.loginUserPermission, ["HM_SADMIN"])
    }

    componentDidMount() {
        this.mslInstance.acquireTokenSilent({
            ...loginRequest,
            account: this.loginUserRoles
        }).then((response) => {
          console.log(response.accessToken);
            //callMsGraph(response.accessToken).then(response => setGraphData(response));
            this.setState({ accessToken: response.accessToken })
        });
    }

    handleBrandIdChange = event => {
        this.setState({ brandId: event.target.value });
    }

    handleBrandNameChange = event => {
        this.setState({ name: event.target.value });
    }

    backBtnClick = (event) => {
        event.preventDefault();
        window.location.href = '/brands';
    };

    handleSubmit = event => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            this.setState({ validated: true });
            event.preventDefault();
            event.stopPropagation();
        }
        else {
            event.preventDefault();

            const brandDetail = {
                brandId: this.state.brandId,
                name: this.state.name
            };

            getHttpCommon(this.state.accessToken).post('api/brand', brandDetail)
                .then(res => {
                    alert(res.data);
                    window.location.href = '/brands';
                }).catch(function (error) {
                    var response = error.response;
                    var errorMessage = response.data.detail;
                    alert(errorMessage);
                });
        }
    }

    render() {
        return (
            <div id="container" className="containerStyle">
                <div className="row">
                    <div className="col-sm-10 offset-sm-1" style={{ marginTop: '20px' }}>
                        <div className="info-form" style={{ marginTop: '20px', width: '50%', margin: 'auto' }}>
                            <h4>Add New Brand</h4>
                            <Form noValidate validated={this.state.validated} onSubmit={this.handleSubmit}
                                className="form-inline justify-content-center">
                                <Form.Group>
                                    <Form.Label>Brand Id</Form.Label>
                                    <Form.Control
                                        required
                                        type="text"
                                        placeholder="Brand Id"
                                        onChange={this.handleBrandIdChange}
                                    />
                                    <Form.Control.Feedback type="invalid">
                                        Please provide Brand Id
                                    </Form.Control.Feedback>
                                </Form.Group>
                                <Form.Group>
                                    <Form.Label>Brand name</Form.Label>
                                    <Form.Control
                                        required
                                        type="text"
                                        placeholder="Brand name"
                                        onChange={this.handleBrandNameChange}
                                    />
                                    <Form.Control.Feedback type="invalid">
                                        Please provide Brand name
                                    </Form.Control.Feedback>
                                </Form.Group>
                                <div className='form-group'>
                                    <Button type="submit" style={{ marginTop: '10px' }}>Add Brand</Button>
                                    <Button type="submit" onClick={this.backBtnClick} style={{ marginTop: '10px', marginLeft: '10px' }}>Back</Button>
                                </div>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}