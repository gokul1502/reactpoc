import React, { Component } from 'react'
import Container from 'react-bootstrap/Container'
import pdf from './Onboarding Brand.pdf'
import pdf1 from './Onboarding Market.pdf'
import pdf2 from './Onboarding Stores.pdf'
import pdf3 from './Onboarding Users.pdf'
import howtousedoc from './howtosm.pdf'
import UserContext from './Context/SampleContext'
import {validateRole} from '../Constants/Utilities';
import image1 from '../images/index1.jpeg';
import image2 from '../images/index2.jpeg';
import image3 from '../images/index3.jpg';
import image4 from '../images/index4.jpg';
import close from '../images/close.png';
import check from '../images/check.png';

export default class Home extends Component {
  static contextType = UserContext;

  constructor(props, context) {
    super(props, context);
    console.log("Homepage=====>>>>>>", props);
    this.loginUserEmail = context.userEmail;
    this.loginUserName = context.userName;
    this.loginUserRoles = context.userRoles;
  }

  render() {
    return (
      <center>
      <Container className="containerStyleHome">
        <table className="homeImageContainer">
          <tr>
            <td className= 'imageCellStyle'>
            <img src={image1} className="homeImageStyle"/>
            <img src={close} className="cornerImageStyle"/>
            </td>
            <td className= 'imageCellStyle'>
            <img src={image3} className="homeImageStyle"/>
            <img src={check} className="cornerImageStyle"/>
            </td>
          </tr>
          <tr>
            <td colspan="2" style={{ textAlign: 'center' }}>
              <h4 >Help?</h4>
              <a href={howtousedoc} target="_blank" title="Onboarding Brands" rel="noreferrer">Admin Portal Guide for store managers</a>
            </td>
          </tr>
        </table>
        <ul>
        {validateRole(this.loginUserRoles, ["HM_SADMIN","HM_PADMIN"]) && <li><a style={{ display: 'none' }} href={howtousedoc} target="_blank" title="Onboarding Brands" rel="noreferrer">Admin Portal Guide for store managers</a></li>}
        {validateRole(this.loginUserRoles, ["HM_SADMIN","HM_PADMIN"]) && <li><a style={{ display: 'none' }} href={pdf1} target="_blank" title="Onboarding Country" rel="noreferrer">Onboarding Country/Market</a></li>}
        {validateRole(this.loginUserRoles, ["HM_ADMIN", "HM_SADMIN","HM_PADMIN"]) && <li><a style={{ display: 'none' }} href={pdf2} target="_blank" title="Onboarding Stores" rel="noreferrer">Onboarding Stores</a></li>}
        {validateRole(this.loginUserRoles, ["HM_ADMIN", "HM_SADMIN","HM_PADMIN"]) && <li><a style={{ display: 'none' }} href={pdf3} target="_blank" title="Onboarding Users" rel="noreferrer">Onboarding Users</a></li>}
        </ul>
       
      </Container>
      </center>
    )
  }
}